# ElectricScout
Our scouting app and related features
